# WIRE Companion Relay

The cloud bridge that pairs **WIRE on your PC** with the **WIRE Companion PWA on
your iPhone**. One small deployment serves everything:

- `https://<your-relay>/` → the WIRE Companion web app (iPhone)
- `wss://<your-relay>/ws` → the live-output relay (desktop ↔ phone)
- `https://<your-relay>/health` → health check for monitoring

The relay is a **display-layer companion only**: it streams copies of bot
output to your phone. It cannot send commands, cannot modify bots, and stores
nothing on disk (small in-memory backlog only, wiped on restart).

## Deploy in 2 minutes (free, Render.com)

1. Push this folder to your GitHub repository (it lives at `companion-relay/`).
2. Open <https://dashboard.render.com/select-repo> → pick the repo.
3. Render detects `render.yaml` → **Apply** → wait ~1 minute.
4. Copy your URL, e.g. `https://wire-companion-relay.onrender.com`.

> Free tier note: the relay sleeps after 15 min without traffic. The WIRE
> desktop app keeps it awake automatically while it's running. The very first
> connection after a long sleep can take ~30–60 s to wake the service.

## Pair your devices

1. **PC** — WIRE → Settings → *Companion sync* → paste your relay URL →
   **Generate key** → toggle sync on (dot turns green).
2. **iPhone** — open `https://<your-relay>/?key=YOUR-KEY` in Safari
   (the Settings panel shows a ready-made *Copy iPhone link* button),
   then **Share → Add to Home Screen** for the real-app experience.

## Run locally for testing

```bash
cd companion-relay
npm install
npm start          # http://localhost:8787
```

## Protocol (for reference)

- Client → `{ "type": "hello", "role": "publisher" | "viewer", "key": "..." }`
- Publisher → `{ "type": "session", "bots": [...] }` / `{ "type": "backlog", ... }`
  / `{ "type": "message", "botId", "message" }` / `{ "type": "presence", ... }`
- Viewer receives `session`, `backlog`, `message`, `presence`, `viewers`.
- Keys are normalized (`A–Z 0–9`), rooms are isolated per key, viewers are
  read-only by design.
