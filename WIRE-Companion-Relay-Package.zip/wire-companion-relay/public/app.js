/* WIRE Companion — live viewer for WIRE bot output (read-only).
   Pairs with the WIRE desktop app through the companion relay. */
(() => {
  "use strict";

  // ------------------------------------------------------------ helpers --
  const $ = (id) => document.getElementById(id);
  const els = {
    pair: $("pair"), pairKey: $("pair-key"), pairConnect: $("pair-connect"), pairError: $("pair-error"),
    live: $("live"), conn: $("conn"), connLabel: $("conn-label"),
    chips: $("chips"), messages: $("messages"), chat: $("chat"), jump: $("jump"),
    settings: $("settings"), openSettings: $("open-settings"), closeSettings: $("close-settings"),
    themeGrid: $("theme-grid"), setRelay: $("set-relay"), setKey: $("set-key"), setStatus: $("set-status"),
    forget: $("forget"), iosHint: $("ios-hint"), dismissHint: $("dismiss-hint"),
  };

  const store = {
    get(key, fallback) { try { const v = localStorage.getItem(key); return v == null ? fallback : v; } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem(key, value); } catch { /* private mode */ } },
    del(key) { try { localStorage.removeItem(key); } catch { /* */ } },
  };

  const state = {
    key: "",
    ws: null,
    status: "connecting",          // connecting | live | off
    viewers: 0,
    bots: new Map(),               // id -> {id,name,exchange,online}
    order: [],                     // bot ids in display order
    active: null,
    unread: new Map(),             // id -> count
    attempts: 0,
    reconnectTimer: 0,
    stick: true,                   // auto-scroll pinned to bottom
  };

  // -------------------------------------------------------------- theme --
  const THEMES = [
    ["real-black", "Real Black"], ["onyx", "Onyx"], ["midnight", "Midnight"],
    ["deep-blue", "Deep Blue"], ["royal-blue", "Royal Blue"], ["aurora", "Aurora"],
    ["graphite", "Graphite"], ["emerald", "Emerald"], ["amethyst", "Amethyst"],
    ["rose-noir", "Rose Noir"], ["neon", "Neon Pulse"], ["sunset", "Sunset"],
  ];
  const SWATCHES = {
    "real-black": ["#000000", "#101216", "#1d9bf0", "#8b5cf6"],
    onyx: ["#04060b", "#131a26", "#3b82f6", "#06b6d4"],
    midnight: ["#050d1a", "#152338", "#2e90fa", "#8b5cf6"],
    "deep-blue": ["#030c18", "#0f2340", "#0ea5e9", "#6366f1"],
    "royal-blue": ["#060a20", "#181f52", "#6366f1", "#a855f7"],
    aurora: ["#04110e", "#0f2b24", "#14b8a6", "#818cf8"],
    graphite: ["#0b0c0f", "#1d2026", "#475569", "#818cf8"],
    emerald: ["#03110a", "#0c2b1c", "#10b981", "#4ade80"],
    amethyst: ["#0a0616", "#1e1440", "#8b5cf6", "#d946ef"],
    "rose-noir": ["#12060c", "#301223", "#db2777", "#f472b6"],
    neon: ["#050510", "#14142c", "#22d3ee", "#e879f9"],
    sunset: ["#120809", "#31171a", "#f97316", "#ec4899"],
  };

  function applyTheme(id) {
    if (!SWATCHES[id]) id = "real-black";
    document.documentElement.dataset.wireTheme = id;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = SWATCHES[id][0] === "#000000" ? "#000000" : SWATCHES[id][1];
    for (const card of els.themeGrid.children) card.classList.toggle("is-selected", card.dataset.theme === id);
  }

  function buildThemeGrid() {
    els.themeGrid.innerHTML = "";
    for (const [id, name] of THEMES) {
      const card = document.createElement("button");
      card.type = "button";
      card.className = "theme-card";
      card.dataset.theme = id;
      const [bg, surface, a, b] = SWATCHES[id];
      card.innerHTML =
        `<span class="swatches">
           <span style="background:${bg}"></span>
           <span style="background:${surface}"></span>
           <span class="g" style="background:linear-gradient(135deg,${a},${b})"></span>
         </span><span class="theme-name"></span>`;
      card.querySelector(".theme-name").textContent = name;
      card.addEventListener("click", () => { store.set("wire-theme", id); applyTheme(id); });
      els.themeGrid.appendChild(card);
    }
    applyTheme(store.get("wire-theme", "real-black"));
  }

  // ------------------------------------------------------------ helpers --
  function fmtTime(ts) {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }
  function fmtDay(ts) {
    const d = new Date(ts), now = new Date();
    const sameDay = d.toDateString() === now.toDateString();
    if (sameDay) return "Today";
    const yest = new Date(now); yest.setDate(now.getDate() - 1);
    if (d.toDateString() === yest.toDateString()) return "Yesterday";
    return d.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" });
  }
  function initial(name) { return (name || "?").trim().charAt(0).toUpperCase() || "?"; }
  function escapeHtml(text) {
    return text.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  function linkify(text) {
    const safe = escapeHtml(text);
    return safe.replace(/(https?:\/\/[^\s<]+)/g, (m) => `<a href="${m}" target="_blank" rel="noopener noreferrer">${m}</a>`);
  }

  // ------------------------------------------------------------- render --
  function botName(id) { const b = state.bots.get(id); return b ? b.name : "Bot"; }

  function renderChips() {
    els.chips.innerHTML = "";
    if (!state.order.length) { els.chips.style.display = "none"; return; }
    els.chips.style.display = "flex";
    for (const id of state.order) {
      const bot = state.bots.get(id);
      if (!bot) continue;
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "chip" + (id === state.active ? " is-active" : "") + (bot.online ? " is-on" : "");
      const unread = state.unread.get(id) || 0;
      chip.innerHTML =
        `<span class="chip-ava">${escapeHtml(initial(bot.name))}</span>` +
        `<span class="chip-dot"></span>` +
        `<span class="chip-name"></span>` +
        (unread ? `<span class="chip-badge">${unread > 99 ? "99+" : unread}</span>` : "");
      chip.querySelector(".chip-name").textContent = bot.name;
      chip.title = bot.exchange || bot.name;
      chip.addEventListener("click", () => { state.active = id; state.unread.set(id, 0); renderChips(); renderMessages(); });
      els.chips.appendChild(chip);
    }
  }

  function messageNode(botId, m) {
    const mine = m.from === "me";
    const row = document.createElement("div");
    row.className = "row" + (mine ? " me" : "");
    row.dataset.msgId = m.id;

    const ava = document.createElement("span");
    ava.className = "ava" + (mine ? " me-ava" : "");
    ava.textContent = mine ? "You".charAt(0) : initial(botName(botId));

    const stack = document.createElement("div");
    stack.className = "stack";
    const meta = document.createElement("div");
    meta.className = "meta";
    meta.innerHTML = `<span class="who"></span><span></span>`;
    meta.querySelector(".who").textContent = mine ? "You" : botName(botId);
    meta.lastElementChild.textContent = fmtTime(m.ts);

    const bubble = document.createElement("div");
    bubble.className = "bubble " + (mine ? "out" : "in") + (m.mono ? " mono" : "");
    if (!mine && m.tone === "alert") bubble.classList.add("alert");
    if (!mine && m.tone === "trade") bubble.classList.add("trade");
    if (m.mono) bubble.textContent = m.text;
    else bubble.innerHTML = linkify(m.text);

    stack.appendChild(meta);
    stack.appendChild(bubble);
    row.appendChild(ava);
    row.appendChild(stack);
    return row;
  }

  function daySeparatorNode(ts) {
    const sep = document.createElement("div");
    sep.className = "day-sep";
    sep.textContent = fmtDay(ts);
    sep.dataset.day = new Date(ts).toDateString();
    return sep;
  }

  function renderMessages() {
    const botId = state.active;
    els.messages.innerHTML = "";
    const list = botId ? buffered.get(botId) || [] : [];
    if (!state.order.length) {
      els.messages.innerHTML =
        `<div class="empty"><div class="big">W</div>` +
        `Waiting for your PC…<br>Open WIRE on your computer and enable <b>Companion sync</b>.</div>`;
      return;
    }
    if (!list.length) {
      els.messages.innerHTML =
        `<div class="empty"><div class="big">${escapeHtml(initial(botName(botId)))}</div>` +
        `Connected. New output from <b>${escapeHtml(botName(botId))}</b> appears here live.</div>`;
      return;
    }
    let lastDay = "";
    for (const m of list) {
      const day = new Date(m.ts).toDateString();
      if (day !== lastDay) { els.messages.appendChild(daySeparatorNode(m.ts)); lastDay = day; }
      els.messages.appendChild(messageNode(botId, m));
    }
    requestAnimationFrame(scrollToEnd);
  }

  function appendMessage(botId, m) {
    if (!buffered.has(botId)) buffered.set(botId, []);
    const list = buffered.get(botId);
    if (list.some((x) => x.id === m.id)) return;      // dedupe on reconnect replays
    list.push(m);
    if (list.length > 300) list.splice(0, list.length - 300);

    if (botId !== state.active) {
      state.unread.set(botId, Math.min(999, (state.unread.get(botId) || 0) + 1));
      renderChips();
      return;
    }
    const atBottom = state.stick;
    const seps = els.messages.querySelectorAll(".day-sep");
    const lastDay = seps.length ? seps[seps.length - 1].dataset.day : "";
    const day = new Date(m.ts).toDateString();
    if (!lastDay || lastDay !== day) els.messages.appendChild(daySeparatorNode(m.ts));
    // Remove the "connected" empty notice if present
    const empty = els.messages.querySelector(".empty");
    if (empty) empty.remove();
    els.messages.appendChild(messageNode(botId, m));
    if (atBottom) requestAnimationFrame(scrollToEnd);
  }

  function scrollToEnd() {
    els.messages.scrollTop = els.messages.scrollHeight;
  }

  // Chat scroll pinning ------------------------------------------------------
  els.messages.addEventListener("scroll", () => {
    const el = els.messages;
    const distance = el.scrollHeight - el.scrollTop - el.clientHeight;
    state.stick = distance < 60;
    els.jump.classList.toggle("hidden", state.stick);
  });
  els.jump.addEventListener("click", () => { state.stick = true; requestAnimationFrame(scrollToEnd); els.jump.classList.add("hidden"); });

  // -------------------------------------------------------------- socket --
  let buffered = new Map();                        // botId -> messages[]

  function setStatus(status, detail) {
    state.status = status;
    els.conn.classList.remove("conn-live", "conn-connecting", "conn-off");
    if (status === "live") {
      els.conn.classList.add("conn-live");
      els.connLabel.textContent = detail ? `Live · ${detail}` : "Live";
    } else if (status === "connecting") {
      els.conn.classList.add("conn-connecting");
      els.connLabel.textContent = detail || "Connecting…";
    } else {
      els.conn.classList.add("conn-off");
      els.connLabel.textContent = detail || "Offline";
    }
    els.setStatus.textContent = status === "live" ? `Live${detail ? " · " + detail : ""}` : status === "connecting" ? "Connecting…" : "Offline";
  }

  function wsUrl() {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    return `${proto}//${location.host}/ws`;
  }

  function connect() {
    if (!state.key) return;
    clearTimeout(state.reconnectTimer);
    if (state.ws) { try { state.ws.onclose = null; state.ws.close(); } catch { /* */ } state.ws = null; }
    setStatus(state.attempts ? "connecting" : "connecting", state.attempts ? `Reconnecting… (${state.attempts})` : "Connecting…");

    let ws;
    try { ws = new WebSocket(wsUrl()); } catch { scheduleReconnect(); return; }
    state.ws = ws;

    ws.onopen = () => {
      ws.send(JSON.stringify({ type: "hello", role: "viewer", key: state.key, name: "iPhone" }));
    };
    ws.onmessage = (event) => {
      let msg;
      try { msg = JSON.parse(event.data); } catch { return; }
      if (!msg || typeof msg.type !== "string") return;
      switch (msg.type) {
        case "welcome": {
          state.attempts = 0;
          setStatus("live");
          break;
        }
        case "session": {
          const next = new Map();
          const order = [];
          for (const b of Array.isArray(msg.bots) ? msg.bots : []) {
            if (!b || typeof b.id !== "string") continue;
            const prev = state.bots.get(b.id);
            next.set(b.id, { id: b.id, name: b.name || (prev && prev.name) || "Bot", exchange: b.exchange || "", online: Boolean(b.online) });
            order.push(b.id);
          }
          const firstConnect = state.order.length === 0;
          state.bots = next;
          state.order = order;
          if (!state.active || !next.has(state.active)) {
            state.active = order[0] || null;
            if (firstConnect && state.active) state.unread.set(state.active, 0);
          }
          renderChips();
          renderMessages();
          break;
        }
        case "backlog": {
          if (typeof msg.botId !== "string" || !Array.isArray(msg.messages)) break;
          buffered.set(msg.botId, msg.messages.slice(-300));
          if (msg.botId === state.active) renderMessages();
          break;
        }
        case "message": {
          if (typeof msg.botId !== "string" || !msg.message) break;
          appendMessage(msg.botId, msg.message);
          break;
        }
        case "presence": {
          const bot = state.bots.get(msg.botId);
          if (bot) { bot.online = Boolean(msg.online); renderChips(); }
          break;
        }
        case "viewers": {
          state.viewers = Number(msg.count) || 0;
          if (state.status === "live") setStatus("live", state.viewers ? `Live · ${state.viewers} device${state.viewers > 1 ? "s" : ""}` : "Live");
          break;
        }
        case "error": {
          if (msg.error === "invalid-key") {
            setStatus("off", "Wrong key");
            showPair("That pairing key was rejected. Check it in WIRE → Settings → Companion sync.");
          }
          break;
        }
      }
    };
    ws.onclose = () => {
      if (state.ws !== ws) return;
      state.ws = null;
      setStatus("off");
      scheduleReconnect();
    };
    ws.onerror = () => { try { ws.close(); } catch { /* */ } };
  }

  function scheduleReconnect() {
    if (!state.key) return;
    state.attempts += 1;
    const delay = Math.min(30_000, 800 * Math.pow(1.7, Math.min(state.attempts, 8))) + Math.random() * 400;
    setStatus("connecting", state.attempts > 1 ? `Retrying in ${Math.round(delay / 1000)}s…` : "Connecting…");
    state.reconnectTimer = setTimeout(connect, delay);
  }

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && state.key && (!state.ws || state.ws.readyState > 1)) connect();
  });

  // ------------------------------------------------------------- pairing --
  function showPair(message) {
    els.live.classList.add("hidden");
    els.pair.classList.remove("hidden");
    if (message) { els.pairError.hidden = false; els.pairError.textContent = message; }
    setTimeout(() => els.pairKey.focus(), 60);
  }

  function showLive() {
    els.pair.classList.add("hidden");
    els.live.classList.remove("hidden");
  }

  function normalizeKey(raw) {
    return String(raw || "").toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 24);
  }

  function startWithKey(key) {
    state.key = key;
    store.set("wire-key", key);
    els.setKey.textContent = key;
    showLive();
    setStatus("connecting");
    state.attempts = 0;
    connect();
  }

  els.pairConnect.addEventListener("click", () => {
    const key = normalizeKey(els.pairKey.value);
    if (key.replace(/-/g, "").length < 6) {
      els.pairError.hidden = false;
      els.pairError.textContent = "Enter the full pairing key from WIRE → Settings → Companion sync.";
      return;
    }
    els.pairError.hidden = true;
    startWithKey(key);
  });
  els.pairKey.addEventListener("keydown", (e) => { if (e.key === "Enter") els.pairConnect.click(); });

  // ------------------------------------------------------------ settings --
  function openSettings() { els.settings.classList.remove("hidden"); }
  function closeSettings() { els.settings.classList.add("hidden"); }
  els.openSettings.addEventListener("click", openSettings);
  els.closeSettings.addEventListener("click", closeSettings);
  els.settings.addEventListener("click", (e) => { if (e.target === els.settings) closeSettings(); });

  els.forget.addEventListener("click", () => {
    store.del("wire-key");
    state.key = "";
    if (state.ws) { try { state.ws.onclose = null; state.ws.close(); } catch { /* */ } state.ws = null; }
    clearTimeout(state.reconnectTimer);
    state.bots = new Map(); state.order = []; state.active = null; buffered = new Map(); state.unread = new Map();
    closeSettings();
    showPair();
  });

  // ----------------------------------------------------------- iOS hint --
  function standalone() {
    return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
  }
  if (!standalone() && !store.get("wire-hint-dismissed", "")) {
    if (/iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)) {
      els.iosHint.classList.remove("hidden");
    }
  }
  els.dismissHint.addEventListener("click", () => {
    els.iosHint.classList.add("hidden");
    store.set("wire-hint-dismissed", "1");
  });

  // --------------------------------------------------------------- boot --
  buildThemeGrid();
  const params = new URLSearchParams(location.search);
  const urlKey = params.get("key");
  if (urlKey) {
    const keep = params.get("source") === "pwa" ? "?source=pwa" : "";
    history.replaceState(null, "", location.pathname + keep);
    startWithKey(normalizeKey(urlKey));
  } else {
    const saved = normalizeKey(store.get("wire-key", ""));
    if (saved) startWithKey(saved);
    else showPair();
  }

  els.setRelay.textContent = location.host;
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("/sw.js").catch(() => { /* offline shell is optional */ });
    });
  }
})();
